import 'package:flutter/widgets.dart';

Widget alertDialog(BuildContext context, String title, String content) {
  throw 'Platform not supported';
}
