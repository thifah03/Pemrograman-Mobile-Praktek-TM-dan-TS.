import '../theme_prefs.dart';

MyDatabase constructDb({bool logStatements = false}) {
  throw 'Platform not supported';
}
