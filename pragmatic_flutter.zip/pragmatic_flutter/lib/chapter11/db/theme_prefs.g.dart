// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'theme_prefs.dart';

// ignore_for_file: type=lint
class $ThemePrefsTable extends ThemePrefs
    with TableInfo<$ThemePrefsTable, ThemePref> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ThemePrefsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _themeIdMeta =
      const VerificationMeta('themeId');
  @override
  late final GeneratedColumn<int> themeId = GeneratedColumn<int>(
      'theme_id', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _themeNameMeta =
      const VerificationMeta('themeName');
  @override
  late final GeneratedColumn<String> themeName = GeneratedColumn<String>(
      'theme_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [themeId, themeName];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'theme_prefs';
  @override
  VerificationContext validateIntegrity(Insertable<ThemePref> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('theme_id')) {
      context.handle(_themeIdMeta,
          themeId.isAcceptableOrUnknown(data['theme_id']!, _themeIdMeta));
    } else if (isInserting) {
      context.missing(_themeIdMeta);
    }
    if (data.containsKey('theme_name')) {
      context.handle(_themeNameMeta,
          themeName.isAcceptableOrUnknown(data['theme_name']!, _themeNameMeta));
    } else if (isInserting) {
      context.missing(_themeNameMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => const {};
  @override
  ThemePref map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ThemePref(
      themeId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}theme_id'])!,
      themeName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}theme_name'])!,
    );
  }

  @override
  $ThemePrefsTable createAlias(String alias) {
    return $ThemePrefsTable(attachedDatabase, alias);
  }
}

class ThemePref extends DataClass implements Insertable<ThemePref> {
  final int themeId;
  final String themeName;
  const ThemePref({required this.themeId, required this.themeName});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['theme_id'] = Variable<int>(themeId);
    map['theme_name'] = Variable<String>(themeName);
    return map;
  }

  ThemePrefsCompanion toCompanion(bool nullToAbsent) {
    return ThemePrefsCompanion(
      themeId: Value(themeId),
      themeName: Value(themeName),
    );
  }

  factory ThemePref.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ThemePref(
      themeId: serializer.fromJson<int>(json['themeId']),
      themeName: serializer.fromJson<String>(json['themeName']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'themeId': serializer.toJson<int>(themeId),
      'themeName': serializer.toJson<String>(themeName),
    };
  }

  ThemePref copyWith({int? themeId, String? themeName}) => ThemePref(
        themeId: themeId ?? this.themeId,
        themeName: themeName ?? this.themeName,
      );
  ThemePref copyWithCompanion(ThemePrefsCompanion data) {
    return ThemePref(
      themeId: data.themeId.present ? data.themeId.value : this.themeId,
      themeName: data.themeName.present ? data.themeName.value : this.themeName,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ThemePref(')
          ..write('themeId: $themeId, ')
          ..write('themeName: $themeName')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(themeId, themeName);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ThemePref &&
          other.themeId == this.themeId &&
          other.themeName == this.themeName);
}

class ThemePrefsCompanion extends UpdateCompanion<ThemePref> {
  final Value<int> themeId;
  final Value<String> themeName;
  final Value<int> rowid;
  const ThemePrefsCompanion({
    this.themeId = const Value.absent(),
    this.themeName = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ThemePrefsCompanion.insert({
    required int themeId,
    required String themeName,
    this.rowid = const Value.absent(),
  })  : themeId = Value(themeId),
        themeName = Value(themeName);
  static Insertable<ThemePref> custom({
    Expression<int>? themeId,
    Expression<String>? themeName,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (themeId != null) 'theme_id': themeId,
      if (themeName != null) 'theme_name': themeName,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ThemePrefsCompanion copyWith(
      {Value<int>? themeId, Value<String>? themeName, Value<int>? rowid}) {
    return ThemePrefsCompanion(
      themeId: themeId ?? this.themeId,
      themeName: themeName ?? this.themeName,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (themeId.present) {
      map['theme_id'] = Variable<int>(themeId.value);
    }
    if (themeName.present) {
      map['theme_name'] = Variable<String>(themeName.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ThemePrefsCompanion(')
          ..write('themeId: $themeId, ')
          ..write('themeName: $themeName, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$MyDatabase extends GeneratedDatabase {
  _$MyDatabase(QueryExecutor e) : super(e);
  $MyDatabaseManager get managers => $MyDatabaseManager(this);
  late final $ThemePrefsTable themePrefs = $ThemePrefsTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [themePrefs];
}

typedef $$ThemePrefsTableCreateCompanionBuilder = ThemePrefsCompanion Function({
  required int themeId,
  required String themeName,
  Value<int> rowid,
});
typedef $$ThemePrefsTableUpdateCompanionBuilder = ThemePrefsCompanion Function({
  Value<int> themeId,
  Value<String> themeName,
  Value<int> rowid,
});

class $$ThemePrefsTableFilterComposer
    extends Composer<_$MyDatabase, $ThemePrefsTable> {
  $$ThemePrefsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get themeId => $composableBuilder(
      column: $table.themeId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get themeName => $composableBuilder(
      column: $table.themeName, builder: (column) => ColumnFilters(column));
}

class $$ThemePrefsTableOrderingComposer
    extends Composer<_$MyDatabase, $ThemePrefsTable> {
  $$ThemePrefsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get themeId => $composableBuilder(
      column: $table.themeId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get themeName => $composableBuilder(
      column: $table.themeName, builder: (column) => ColumnOrderings(column));
}

class $$ThemePrefsTableAnnotationComposer
    extends Composer<_$MyDatabase, $ThemePrefsTable> {
  $$ThemePrefsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get themeId =>
      $composableBuilder(column: $table.themeId, builder: (column) => column);

  GeneratedColumn<String> get themeName =>
      $composableBuilder(column: $table.themeName, builder: (column) => column);
}

class $$ThemePrefsTableTableManager extends RootTableManager<
    _$MyDatabase,
    $ThemePrefsTable,
    ThemePref,
    $$ThemePrefsTableFilterComposer,
    $$ThemePrefsTableOrderingComposer,
    $$ThemePrefsTableAnnotationComposer,
    $$ThemePrefsTableCreateCompanionBuilder,
    $$ThemePrefsTableUpdateCompanionBuilder,
    (ThemePref, BaseReferences<_$MyDatabase, $ThemePrefsTable, ThemePref>),
    ThemePref,
    PrefetchHooks Function()> {
  $$ThemePrefsTableTableManager(_$MyDatabase db, $ThemePrefsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ThemePrefsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ThemePrefsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ThemePrefsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> themeId = const Value.absent(),
            Value<String> themeName = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ThemePrefsCompanion(
            themeId: themeId,
            themeName: themeName,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required int themeId,
            required String themeName,
            Value<int> rowid = const Value.absent(),
          }) =>
              ThemePrefsCompanion.insert(
            themeId: themeId,
            themeName: themeName,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ThemePrefsTableProcessedTableManager = ProcessedTableManager<
    _$MyDatabase,
    $ThemePrefsTable,
    ThemePref,
    $$ThemePrefsTableFilterComposer,
    $$ThemePrefsTableOrderingComposer,
    $$ThemePrefsTableAnnotationComposer,
    $$ThemePrefsTableCreateCompanionBuilder,
    $$ThemePrefsTableUpdateCompanionBuilder,
    (ThemePref, BaseReferences<_$MyDatabase, $ThemePrefsTable, ThemePref>),
    ThemePref,
    PrefetchHooks Function()>;

class $MyDatabaseManager {
  final _$MyDatabase _db;
  $MyDatabaseManager(this._db);
  $$ThemePrefsTableTableManager get themePrefs =>
      $$ThemePrefsTableTableManager(_db, _db.themePrefs);
}
