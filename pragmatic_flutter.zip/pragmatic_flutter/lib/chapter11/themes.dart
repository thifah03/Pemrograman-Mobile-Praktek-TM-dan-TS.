import 'package:flutter/material.dart';

/// Chapter11: Persisting Data
///
enum AppThemes { light, dark }

// Themes definitions
ThemeData get defaultTheme => ThemeData(
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: Colors.blue,
        secondary: Colors.lightBlueAccent,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.blue,
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
      ),
    );

ThemeData get pinkTheme => ThemeData(
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: Colors.pink,
        secondary: Colors.pinkAccent,
      ),
    );

ThemeData get darkTheme => ThemeData(
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: Colors.orange,
        secondary: Colors.yellowAccent,
      ),
    );
