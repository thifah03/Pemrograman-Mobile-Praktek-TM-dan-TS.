import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Sesuaikan path import ini
import '../../../config.dart'; 
import 'booktile.dart';

void main() => runApp(BooksApp());

class BooksApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true, 
        colorSchemeSeed: Colors.indigo,
      ),
      home: BooksListing(),
    );
  }
}

// Tambahkan pengembalian data yang lebih eksplisit
Future<Map<String, dynamic>?> makeHttpCall() async {
  // Gunakan variabel YOUR_API_KEY dari config.dart
  final apiKey = YOUR_API_KEY; 
  final url = Uri.parse("https://www.googleapis.com/books/v1/volumes?q=python+coding&key=$apiKey");
  
  try {
    final response = await http.get(
      url, 
      headers: {'Accept': 'application/json'}
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      debugPrint("API Error: ${response.statusCode}");
      return null;
    }
  } catch (e) {
    debugPrint("Connection Exception: $e");
    return null;
  }
}

class BooksListing extends StatefulWidget {
  @override
  _BooksListingState createState() => _BooksListingState();
}

class _BooksListingState extends State<BooksListing> {
  List? booksListing;
  bool isLoading = true;

  // Gunakan fungsi async dengan penanganan error
  Future<void> fetchBooks() async {
    if (!mounted) return;
    setState(() => isLoading = true);

    final response = await makeHttpCall();

    if (mounted) {
      setState(() {
        // Memastikan response tidak null dan memiliki field 'items'
        booksListing = (response != null && response.containsKey('items')) 
            ? response['items'] 
            : [];
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchBooks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Books Listing"),
        centerTitle: true,
        elevation: 2,
      ),
      // Tombol refresh jika data kosong atau ingin update
      floatingActionButton: FloatingActionButton(
        onPressed: fetchBooks,
        child: const Icon(Icons.refresh),
      ),
      body: isLoading 
        ? const Center(child: CircularProgressIndicator())
        : booksListing == null || booksListing!.isEmpty
            ? const Center(child: Text("Buku tidak ditemukan atau terjadi kesalahan."))
            : ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: booksListing!.length,
                itemBuilder: (context, index) {
                  return BookTile(book: booksListing![index]);
                },
              ),
    );
  }
}