import 'package:flutter/material.dart';

class BookTile extends StatelessWidget {
  final dynamic book;
  BookTile({required this.book});

  @override
  Widget build(BuildContext context) {
    final info = book['volumeInfo'];
    final String? thumb = info['imageLinks']?['thumbnail'];
    
    // SOLUSI GAMBAR: Menggunakan proxy agar tidak error statusCode: 0 di Chrome
    final String imageUrl = thumb != null 
        ? "https://images.weserv.nl/?url=${Uri.encodeComponent(thumb.replaceFirst('http://', 'https://'))}"
        : "https://via.placeholder.com/150";

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar buku dengan ukuran tetap
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Image.network(
                imageUrl,
                width: 70,
                height: 100,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stack) => Icon(Icons.book, size: 70),
              ),
            ),
            SizedBox(width: 12),
            // Gunakan Expanded agar teks tidak menyebabkan overflow (garis kuning)
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    info['title'] ?? 'No Title',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    maxLines: 2, // Batasi 2 baris agar rapi
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 4),
                  Text(
                    info['authors']?.join(', ') ?? 'Unknown Author',
                    style: TextStyle(color: Colors.grey[600]),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}