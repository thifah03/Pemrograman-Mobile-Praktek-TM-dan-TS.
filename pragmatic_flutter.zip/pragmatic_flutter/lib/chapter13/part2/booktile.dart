import 'package:flutter/material.dart';
import 'bookmodel.dart';

class BookTile extends StatelessWidget {
  final BookModel bookModelObj;

  // FIX: Menggunakan super.key dan required untuk Null Safety
  const BookTile({super.key, required this.bookModelObj});

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      elevation: 5,
      margin: const EdgeInsets.all(10),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    bookModelObj.volumeInfo.title, // Tidak perlu String interpolation '${}' jika hanya satu variabel
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  // FIX: Cek null yang aman untuk authors
                  if (bookModelObj.volumeInfo.authors != null && bookModelObj.volumeInfo.authors!.isNotEmpty)
                    Text(
                      'Author(s): ${bookModelObj.volumeInfo.authors!.join(", ")}',
                      style: const TextStyle(fontSize: 14),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 10), // Tambahkan sedikit jarak antara teks dan gambar
            // FIX: Akses imageLinks secara aman menggunakan ?.
            bookModelObj.volumeInfo.imageLinks?.thumbnail != null
                ? Image.network(
                    bookModelObj.volumeInfo.imageLinks!.thumbnail!,
                    width: 70, // Beri ukuran tetap agar UI rapi
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => const Icon(Icons.book, size: 50), // Fallback jika gambar error
                  )
                : const SizedBox(
                    width: 70,
                    height: 100,
                    child: Icon(Icons.book_outlined, size: 50),
                  ),
          ],
        ),
      ),
    );
  }
}