import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Pastikan file config.dart Anda berisi: const String YOUR_API_KEY = "key_anda";
import '../../config.dart'; 
import 'bookmodel.dart';
import 'booktile.dart';

void main() => runApp(const BooksApp());

class BooksApp extends StatelessWidget {
  const BooksApp({super.key}); // Ditambahkan constructor const & super.key

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const BooksListing(),
    );
  }
}

// Fungsi HTTP Call yang diperbaiki
Future<List<BookModel>> makeHttpCall() async {
  // FIX: Panggil variabel YOUR_API_KEY langsung (tanpa tanda $)
  final apiKey = YOUR_API_KEY; 
  final apiEndpoint =
      "https://www.googleapis.com/books/v1/volumes?key=$apiKey&q=python+coding";
  
  final http.Response response = await http
      .get(Uri.parse(apiEndpoint), headers: {'Accept': 'application/json'});

  if (response.statusCode == 200) {
    final jsonObject = json.decode(response.body);
    
    // Safety check jika item tidak ditemukan
    if (jsonObject['items'] == null) return [];

    var list = jsonObject['items'] as List;
    return list.map((e) => BookModel.fromJson(e)).toList();
  } else {
    throw Exception('Gagal memuat buku');
  }
}

class BooksListing extends StatefulWidget {
  const BooksListing({super.key});

  @override
  _BooksListingState createState() => _BooksListingState();
}

class _BooksListingState extends State<BooksListing> {
  // FIX 1: Gunakan 'late' atau inisialisasi list kosong agar tidak error non-nullable
  List<BookModel> booksListing = [];
  bool isLoading = true; // Tambahan untuk indikator loading

  fetchBooks() async {
    try {
      var response = await makeHttpCall();
      if (!mounted) return;

      setState(() {
        booksListing = response;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoading = false);
      print("Error: $e");
    }
  }

  @override
  void initState() {
    super.initState();
    fetchBooks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Books Listing"),
      ),
      // FIX 2: Tampilkan loading spinner jika data belum siap
      body: isLoading 
          ? const Center(child: CircularProgressIndicator())
          : booksListing.isEmpty
              ? const Center(child: Text("Buku tidak ditemukan"))
              : ListView.builder(
                  itemCount: booksListing.length,
                  itemBuilder: (context, index) {
                    return BookTile(bookModelObj: booksListing[index]);
                  },
                ),
    );
  }
}