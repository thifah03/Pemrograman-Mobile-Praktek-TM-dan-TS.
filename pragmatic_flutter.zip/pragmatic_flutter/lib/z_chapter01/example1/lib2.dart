bool isNumberOdd(int num) => num.isOdd;

bool isNumberEven(int num) => num.isEven;

//Added to demonstrate handle conflicting name in two different libraries
int addition(int a, int b) => a + b + 2;
