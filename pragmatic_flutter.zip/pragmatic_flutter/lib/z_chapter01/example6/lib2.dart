part of 'lib1.dart';

bool isNumberOdd(int num) => num.isOdd;

bool isNumberEven(int num) => num.isEven;
