// lib/config.dart

// Masukkan API Key yang Anda dapatkan dari Google Cloud Console di sini
const String YOUR_API_KEY = "AIzaSyDaZEPzRSg2VeUkY1L8tLgUiIdClqOmId8";