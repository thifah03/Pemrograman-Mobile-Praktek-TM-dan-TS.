import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../config.dart';

void main() => runApp(const BooksApp());

class BooksApp extends StatelessWidget {
  const BooksApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const BooksListing(),
    );
  }
}

class BooksListing extends StatefulWidget {
  const BooksListing({super.key});

  @override
  _BooksListingState createState() => _BooksListingState();
}

class _BooksListingState extends State<BooksListing> {
  List items = [];
  bool isLoading = false;
  String errorMessage = '';
  // Controller untuk fitur pencarian
  final TextEditingController _searchController = TextEditingController(text: 'python coding');

  Future<void> fetchBooks(String query) async {
    if (query.isEmpty) return;

    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    const apiKey = YOUR_API_KEY;
    final url = Uri.parse("https://www.googleapis.com/books/v1/volumes?q=${Uri.encodeComponent(query)}&key=$apiKey");

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          items = data['items'] ?? [];
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = "Error ${response.statusCode}: Gagal mengambil data";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Koneksi bermasalah. Pastikan API Key aktif.";
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchBooks(_searchController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Bookshelf"),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Cari judul buku...",
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () => _searchController.clear(),
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
              onSubmitted: (value) => fetchBooks(value),
            ),
          ),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage, style: const TextStyle(color: Colors.red)))
              : items.isEmpty
                  ? const Center(child: Text("Buku tidak ditemukan"))
                  : ListView.builder(
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        final book = items[index]['volumeInfo'];
                        
                        // SOLUSI GAMBAR: Menggunakan Image Proxy (weserv.nl) untuk bypass CORS
                        String? rawThumbnail = book['imageLinks']?['thumbnail'];
                        String imageUrl = "https://via.placeholder.com/150";
                        
                        if (rawThumbnail != null) {
                          // Kita bungkus URL asli ke dalam proxy agar bisa tampil di browser
                          imageUrl = "https://images.weserv.nl/?url=${Uri.encodeComponent(rawThumbnail.replaceFirst('http://', 'https://'))}";
                        }

                        return Card(
                          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          elevation: 2,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    imageUrl,
                                    width: 80,
                                    height: 120,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stack) => Container(
                                      width: 80, height: 120, color: Colors.grey[200],
                                      child: const Icon(Icons.broken_image),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        book['title'] ?? 'No Title',
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                        maxLines: 2, overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        book['authors']?.join(', ') ?? 'Unknown Author',
                                        style: TextStyle(color: Colors.grey[700]),
                                        maxLines: 1, overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 8),
                                      if (book['averageRating'] != null)
                                        Row(
                                          children: [
                                            const Icon(Icons.star, color: Colors.amber, size: 18),
                                            Text(" ${book['averageRating']}"),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}