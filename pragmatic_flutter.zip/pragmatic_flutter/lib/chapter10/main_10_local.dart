//Building BooksApp App's User Interface.
//Local theme demonstration
import 'package:flutter/material.dart';

import 'themes.dart';

void main() {
  runApp(BooksApp());
}

//void main() => runApp(BooksApp());

//Showing book listing in ListView
class BooksApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: defaultTheme,
      home: Scaffold(
        appBar: AppBar(
          leading: Icon(Icons.home),
          title: Text("Books Listing"),
        ),
        body: BooksListing(),
      ),
    );
  }
}

List<Map<String, dynamic>> bookData() {
  return [
    {
      'title': 'Book Title',
      'authors': ['Author1', 'Author2'],
      'image': 'assets/book_cover.png'
    },
    {
      'title': 'Book Title 2',
      'authors': ['Author1'],
      'image': 'assets/book_cover.png'
    }
  ];
}

class BooksListing extends StatelessWidget {
  final List<Map<String, dynamic>> booksListing = bookData();

  @override
  Widget build(BuildContext context) {
    return Theme(
      // Local Theme only for Card
      data: ThemeData(
        cardColor: Colors.pinkAccent,
        textTheme: TextTheme(
          titleLarge: TextStyle(
            fontFamily: 'Pangolin',
            fontSize: 20,
          ),
          bodyMedium: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontStyle: FontStyle.italic,
              ),
        ),
      ),
      child: ListView.builder(
        itemCount: booksListing.length,
        itemBuilder: (context, index) {
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(10),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          booksListing[index]['title'],
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        Text(
                          'Author(s): ${booksListing[index]['authors'].join(", ")}',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  Image.asset(
                    booksListing[index]['image'],
                    fit: BoxFit.fill,
                    width: 60,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
