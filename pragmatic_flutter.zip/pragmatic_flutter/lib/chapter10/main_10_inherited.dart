/// Switching Themes using InheritedWidget
import 'package:flutter/material.dart';
import 'booklisting.dart';

// void main() => runApp(BooksApp());

class BooksApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootWidget(
      child: BooksAppScreen(
        child: BooksListing(),
      ),
    );
  }
}

/* ================= ROOT WIDGET ================= */

class RootWidget extends StatefulWidget {
  final Widget child;

  const RootWidget({
    Key? key,
    required this.child,
  }) : super(key: key);

  static RootWidgetState of(BuildContext context) {
    final inherited =
        context.dependOnInheritedWidgetOfExactType<MyInheritedWidget>();
    assert(inherited != null, 'MyInheritedWidget not found in context');
    return inherited!.data;
  }

  @override
  RootWidgetState createState() => RootWidgetState();
}

class RootWidgetState extends State<RootWidget> {
  MyThemes _currentTheme = MyThemes.light;
  MyThemes get currentTheme => _currentTheme;

  void switchTheme() {
    setState(() {
      _currentTheme =
          _currentTheme == MyThemes.light ? MyThemes.dark : MyThemes.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MyInheritedWidget(
      data: this,
      child: widget.child,
    );
  }
}

/* ================= INHERITED WIDGET ================= */

class MyInheritedWidget extends InheritedWidget {
  final RootWidgetState data;

  const MyInheritedWidget({
    Key? key,
    required Widget child,
    required this.data,
  }) : super(key: key, child: child);

  @override
  bool updateShouldNotify(MyInheritedWidget oldWidget) {
    return true;
  }
}

/* ================= APP SCREEN ================= */

class BooksAppScreen extends StatelessWidget {
  final Widget child;

  const BooksAppScreen({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final themeIndex =
        RootWidget.of(context).currentTheme == MyThemes.light ? 0 : 1;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: themeData[themeIndex],
      home: Scaffold(
        appBar: AppBar(
          leading: const Icon(Icons.home),
          title: const Text("Books Listing"),
          actions: [
            IconButton(
              icon: const Icon(Icons.all_inclusive),
              onPressed: () => RootWidget.of(context).switchTheme(),
            )
          ],
        ),
        body: child,
      ),
    );
  }
}

/* ================= THEME ================= */

enum MyThemes { light, dark }

final List<ThemeData> themeData = [
  ThemeData(
    brightness: Brightness.light,
    primaryColor: Colors.blue,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blue,
      secondary: Colors.lightBlueAccent,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.blue,
    ),
  ),
  ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.orange,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.orange,
      secondary: Colors.yellowAccent,
      brightness: Brightness.dark,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.orange,
    ),
  ),
];
