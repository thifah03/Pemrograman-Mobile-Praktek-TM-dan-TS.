/// Switching Themes using Provider package
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'booklisting.dart';
import 'themes_notifier.dart';

// Entry point to app (AKTIFKAN SAAT MAU RUN FILE INI)
// void main() {
//   runApp(
//     ChangeNotifierProvider(
//       create: (_) => ThemesNotifier(),
//       child: BooksApp(),
//     ),
//   );
// }

class BooksApp extends StatefulWidget {
  @override
  State<BooksApp> createState() => _BooksAppState();
}

class _BooksAppState extends State<BooksApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: Provider.of<ThemesNotifier>(context).currentThemeData,
      home: Scaffold(
        appBar: AppBar(
          leading: const Icon(Icons.home),
          title: const Text("Books Listing"),
          actions: [
            IconButton(
              icon: const Icon(Icons.all_inclusive),
              onPressed: () {
                Provider.of<ThemesNotifier>(context, listen: false)
                    .switchTheme();
              },
            ),
          ],
        ),
        body: BooksListing(),
      ),
    );
  }

  Widget body() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Image.asset("assets/book_cover.png"),
          ),
          const SizedBox(height: 20),
          const Text(
            "Beautiful Ocean",
            style: TextStyle(fontSize: 20),
          ),
          const SizedBox(height: 30),

          /// ✅ FIX: RaisedButton → ElevatedButton
          ElevatedButton(
            onPressed: () {
              Provider.of<ThemesNotifier>(context, listen: false)
                  .switchTheme();
            },
            child: const Text("Switch Theme"),
          ),
        ],
      ),
    );
  }
}
