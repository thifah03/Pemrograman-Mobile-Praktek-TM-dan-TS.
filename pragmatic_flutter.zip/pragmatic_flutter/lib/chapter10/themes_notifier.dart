import 'package:flutter/material.dart';

// Switching themes using Provider
enum MyThemes { light, dark }

class ThemesNotifier with ChangeNotifier {
  // Current theme
  MyThemes _currentTheme = MyThemes.light;

  MyThemes get currentTheme => _currentTheme;

  ThemeData get currentThemeData =>
      _currentTheme == MyThemes.light ? lightTheme : darkTheme;

  void switchTheme() {
    _currentTheme =
        _currentTheme == MyThemes.light ? MyThemes.dark : MyThemes.light;
    notifyListeners();
  }
}

/// LIGHT THEME
final ThemeData lightTheme = ThemeData(
  brightness: Brightness.light,
  colorScheme: ColorScheme.fromSeed(
    seedColor: Colors.blue,
    brightness: Brightness.light,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.blue,
    foregroundColor: Colors.white,
  ),
);

/// DARK THEME
final ThemeData darkTheme = ThemeData(
  brightness: Brightness.dark,
  colorScheme: ColorScheme.fromSeed(
    seedColor: Colors.orange,
    brightness: Brightness.dark,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.orange,
    foregroundColor: Colors.black,
  ),
);
