import 'package:flutter/material.dart';
import 'book.dart';

class BookTile extends StatelessWidget {
  final BookModel bookModelObj;

  // 1. Perbaikan Konstruktor untuk Null Safety
  const BookTile({super.key, required this.bookModelObj});

  @override
  Widget build(BuildContext context) {
    // Mempermudah akses ke volumeInfo
    final info = bookModelObj.volumeInfo;

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      elevation: 5,
      margin: const EdgeInsets.all(10),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // 2. Gunakan operator ?. dan ?? untuk menghindari error null
                  Text(
                    info?.title ?? "No Title",
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.bold),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  if (info?.authors != null)
                    Text(
                      'Author(s): ${info!.authors!.join(", ")}',
                      style: const TextStyle(fontSize: 12),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    )
                  else
                    const Text("Unknown Author",
                        style: TextStyle(fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            // 3. Penanganan Gambar yang lebih aman
            _buildThumbnail(info?.imageLinks?.thumbnail),
          ],
        ),
      ),
    );
  }

  // Helper widget untuk menangani gambar null
  Widget _buildThumbnail(String? thumbnailUrl) {
    if (thumbnailUrl != null && thumbnailUrl.isNotEmpty) {
      return Image.network(
        thumbnailUrl,
        width: 60,
        height: 90,
        fit: BoxFit.cover,
        // Menangani error jika URL gambar tidak valid/rusak
        errorBuilder: (context, error, stackTrace) => _placeholder(),
      );
    }
    return _placeholder();
  }

  Widget _placeholder() {
    return Container(
      width: 60,
      height: 90,
      color: Colors.grey[300],
      child: const Icon(Icons.book, color: Colors.grey),
    );
  }
}