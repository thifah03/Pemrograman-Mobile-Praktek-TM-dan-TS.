class BookModel {
  final VolumeInfo? volumeInfo;
  final AccessInfo? accessInfo;
  final SaleInfo? saleInfo;

  // Gunakan tanda ? agar parameter ini boleh null secara implisit
  BookModel({
    this.volumeInfo,
    this.accessInfo,
    this.saleInfo,
  });

  factory BookModel.fromJson(Map<String, dynamic> json) {
    return BookModel(
      volumeInfo: json['volumeInfo'] != null
          ? VolumeInfo.fromJson(json['volumeInfo'])
          : null,
      accessInfo: json['accessInfo'] != null
          ? AccessInfo.fromJson(json['accessInfo'])
          : null,
      saleInfo:
          json['saleInfo'] != null ? SaleInfo.fromJson(json['saleInfo']) : null,
    );
  }
}

class VolumeInfo {
  final String? title;
  final String? subtitle;
  final List<dynamic>? authors;
  final String? publisher;
  final String? publishedDate;
  final String? description;
  final ImageLinks? imageLinks;

  VolumeInfo({
    this.title,
    this.subtitle,
    this.authors,
    this.publisher,
    this.publishedDate,
    this.description,
    this.imageLinks,
  });

  factory VolumeInfo.fromJson(Map<String, dynamic> json) {
    return VolumeInfo(
      title: json['title'],
      subtitle: json['subtitle'],
      authors: json['authors'],
      publisher: json['publisher'],
      publishedDate: json['publishedDate'],
      description: json['description'],
      imageLinks: json['imageLinks'] != null
          ? ImageLinks.fromJson(json['imageLinks'])
          : null,
    );
  }
}

class ImageLinks {
  final String? thumbnail;
  ImageLinks({this.thumbnail});

  factory ImageLinks.fromJson(Map<String, dynamic> json) {
    return ImageLinks(thumbnail: json['thumbnail']);
  }
}

// Tambahkan class AccessInfo dan SaleInfo untuk mendukung ActionsWidget
class AccessInfo {
  final String? webReaderLink;
  AccessInfo({this.webReaderLink});

  factory AccessInfo.fromJson(Map<String, dynamic> json) {
    return AccessInfo(webReaderLink: json['webReaderLink']);
  }
}

class SaleInfo {
  final String? saleability;
  final String? buyLink;
  SaleInfo({this.saleability, this.buyLink});

  factory SaleInfo.fromJson(Map<String, dynamic> json) {
    return SaleInfo(
      saleability: json['saleability'],
      buyLink: json['buyLink'],
    );
  }
}