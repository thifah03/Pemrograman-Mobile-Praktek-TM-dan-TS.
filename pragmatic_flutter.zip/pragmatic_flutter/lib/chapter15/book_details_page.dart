import 'package:flutter/material.dart';
import 'book.dart'; // Import agar mengenali BookModel

class BookDetailsPage extends StatelessWidget {
  final BookModel book;

  const BookDetailsPage({super.key, required this.book});

  @override
  Widget build(BuildContext context) {
    // Mengambil data dari model yang Anda buat tadi
    final info = book.volumeInfo;

    return Scaffold(
      appBar: AppBar(
        title: Text(info?.title ?? 'Detail Buku'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (info?.imageLinks?.thumbnail != null)
              Center(child: Image.network(info!.imageLinks!.thumbnail!)),
            const SizedBox(height: 20),
            Text(
              info?.title ?? 'No Title',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text(
              "Penulis: ${info?.authors?.join(', ') ?? 'Anonim'}",
              style: const TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const Divider(),
            Text(
              info?.description ?? 'Tidak ada deskripsi.',
              textAlign: TextAlign.justify,
            ),
          ],
        ),
      ),
    );
  }
}