import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Pastikan import ini mengarah ke file tempat Anda menyimpan API Key
import '../config.dart';
import 'book.dart'; // Sumber utama BookModel
// Pastikan baris ini ada:
import 'booktile.dart';
import 'page_not_found.dart';
import 'book_details_page.dart'; // Baris ini yang akan menghilangkan error merah Anda

void main() => runApp(const BooksApp());

class BooksApp extends StatelessWidget {
  const BooksApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Menggunakan initialRoute mengharuskan kita mendefinisikan rute di onGenerateRoute
      initialRoute: '/',
      onGenerateRoute: generateRoute,
    );
  }
}

Route<dynamic> generateRoute(RouteSettings routeSettings) {
  final args = routeSettings.arguments;

  switch (routeSettings.name) {
    case '/':
      return MaterialPageRoute(
        builder: (_) => const BooksListing(),
      );

    case '/details':
      // Pengecekan 'is' ini wajib agar Dart melakukan 'Smart Cast'
      if (args is BookModel) {
        return MaterialPageRoute(
          // Sekarang 'args' secara otomatis dianggap sebagai BookModel
          builder: (_) => BookDetailsPage(book: args),
        );
      }
      return MaterialPageRoute(builder: (_) => PageNotFound());

    default:
      return MaterialPageRoute(builder: (_) => PageNotFound());
  }
}

/// Fungsi untuk mengambil data dari Google Books API
Future<List<BookModel>> makeHttpCall() async {
  // Pastikan variabel apiKey sesuai dengan yang ada di config.dart (misal: Config.apiKey)
  // Jika error, ganti baris di bawah dengan API Key string langsung untuk testing.
  const apiKey = YOUR_API_KEY;
  const apiEndpoint =
      "https://www.googleapis.com/books/v1/volumes?key=$apiKey&q=python+coding";

  try {
    final response = await http.get(
      Uri.parse(apiEndpoint),
      headers: {'Accept': 'application/json'},
    );

    if (response.statusCode == 200) {
      final jsonObject = json.decode(response.body);
      // Null-safety check: Google API mengembalikan null jika tidak ada item
      final List<dynamic>? items = jsonObject['items'];

      if (items != null) {
        return items.map((e) => BookModel.fromJson(e)).toList();
      }
    }
    return [];
  } catch (e) {
    debugPrint("Network Error: $e");
    return [];
  }
}

class BooksListing extends StatefulWidget {
  const BooksListing({super.key});

  @override
  State<BooksListing> createState() => _BooksListingState();
}

class _BooksListingState extends State<BooksListing> {
  List<BookModel> booksListing = [];
  bool isLoading = true;

  Future<void> fetchBooks() async {
    final response = await makeHttpCall();

    // Guard: Jangan panggil setState jika widget sudah tidak ada di layar (context closed)
    if (!mounted) return;

    setState(() {
      booksListing = response;
      isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchBooks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Books Listing"),
        elevation: 2,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : booksListing.isEmpty
              ? const Center(
                  child: Text("No books found or check your API Key."))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: booksListing.length,
                  itemBuilder: (context, index) {
                    final currentBook = booksListing[index];
                    return GestureDetector(
                      onTap: () => Navigator.pushNamed(
                        context,
                        '/details',
                        arguments: currentBook,
                      ),
                      child: BookTile(bookModelObj: currentBook),
                    );
                  },
                ),
    );
  }
}