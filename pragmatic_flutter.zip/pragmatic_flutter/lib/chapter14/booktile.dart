import 'package:flutter/material.dart';
import 'book.dart'; // Import file model Anda yang baru

class BookTile extends StatelessWidget {
  final BookModel bookModelObj;
  const BookTile({super.key, required this.bookModelObj});

  @override
  Widget build(BuildContext context) {
    // 1. Ambil data dari sub-class volumeInfo
    final info = bookModelObj.volumeInfo;
    
    // 2. Ambil URL thumbnail (pakai ? karena ImageLinks bisa null)
    final String? thumb = info.imageLinks?.thumbnail;
    
    // 3. PROXY untuk Chrome (Agar gambar muncul/tidak error statusCode: 0)
    final String secureImageUrl = thumb != null 
        ? "https://images.weserv.nl/?url=${Uri.encodeComponent(thumb.replaceFirst('http://', 'https://'))}"
        : "https://via.placeholder.com/150";

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar Buku
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Image.network(
                secureImageUrl,
                width: 70,
                height: 100,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => 
                    Container(width: 70, height: 100, color: Colors.grey[200], child: const Icon(Icons.book)),
              ),
            ),
            const SizedBox(width: 15),
            
            // SOLUSI OVERFLOW: Gunakan Expanded
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Judul Buku
                  Text(
                    info.title,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  // Nama Penulis (List dinamik diubah menjadi string)
                  Text(
                    info.authors?.join(', ') ?? 'Unknown Author',
                    style: TextStyle(color: Colors.grey[600]),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  // Status Penjualan (Contoh penggunaan SaleInfo)
                  Text(
                    bookModelObj.saleInfo.saleability ?? 'Status Unknown',
                    style: const TextStyle(fontSize: 12, color: Colors.indigo),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}