import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../config.dart';
import 'book.dart';
import 'book_details_page.dart';
import 'booktile.dart';

void main() => runApp(const BooksApp());

class BooksApp extends StatelessWidget {
  const BooksApp({super.key}); // FIX: Tambahkan const dan super.key

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const BooksListing(),
    );
  }
}

// Fungsi HTTP Call yang diperbaiki
Future<List<BookModel>> makeHttpCall() async {
  // FIX: Jangan gunakan "$" jika memanggil variabel konstan dari config.dart
  final apiKey = YOUR_API_KEY; 
  final apiEndpoint =
      "https://www.googleapis.com/books/v1/volumes?key=$apiKey&q=python+coding";
  
  try {
    final http.Response response = await http
        .get(Uri.parse(apiEndpoint), headers: {'Accept': 'application/json'});

    if (response.statusCode == 200) {
      final jsonObject = json.decode(response.body);
      
      // Safety check jika item tidak ditemukan di API
      if (jsonObject['items'] == null) return [];

      var list = jsonObject['items'] as List;
      return list.map((e) => BookModel.fromJson(e)).toList();
    } else {
      return []; // Kembalikan list kosong jika request gagal
    }
  } catch (e) {
    print("Error fetching books: $e");
    return [];
  }
}

class BooksListing extends StatefulWidget {
  const BooksListing({super.key}); // FIX: Tambahkan constructor

  @override
  _BooksListingState createState() => _BooksListingState();
}

class _BooksListingState extends State<BooksListing> {
  // Sudah benar: Inisialisasi list kosong
  List<BookModel> booksListing = [];
  bool isLoading = true; // Tambahan: Indikator loading agar UX lebih baik

  fetchBooks() async {
    var response = await makeHttpCall();
    
    // Safety check: Pastikan widget masih ada di layar saat setState dipanggil
    if (!mounted) return;

    setState(() {
      booksListing = response;
      isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchBooks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Books Listing"),
      ),
      // FIX: Tampilkan loading spinner jika data sedang diambil
      body: isLoading 
          ? const Center(child: CircularProgressIndicator())
          : booksListing.isEmpty
              ? const Center(child: Text("No books found."))
              : ListView.builder(
                  itemCount: booksListing.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      child: BookTile(bookModelObj: booksListing[index]),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => BookDetailsPage(
                            book: booksListing[index],
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}