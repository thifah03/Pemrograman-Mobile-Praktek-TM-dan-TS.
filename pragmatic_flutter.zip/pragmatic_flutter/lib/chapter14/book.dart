class BookModel {
  final VolumeInfo volumeInfo;
  final AccessInfo accessInfo;
  final SaleInfo saleInfo;

  // FIX: Tambahkan 'required' karena variabel di atas tidak boleh null
  BookModel({
    required this.volumeInfo,
    required this.accessInfo,
    required this.saleInfo,
  });

  factory BookModel.fromJson(Map<String, dynamic> json) {
    return BookModel(
      // Gunakan ?? {} agar jika field di JSON kosong, aplikasi tidak crash
      volumeInfo: VolumeInfo.fromJson(json['volumeInfo'] ?? {}),
      accessInfo: AccessInfo.fromJson(json['accessInfo'] ?? {}),
      saleInfo: SaleInfo.fromJson(json['saleInfo'] ?? {}),
    );
  }
}

class VolumeInfo {
  final String title;
  final String? subtitle;      // Pakai ? karena data ini sering tidak ada
  final String? description;   // Pakai ? agar tidak error saat deskripsi kosong
  final List<dynamic>? authors;
  final String? publisher;
  final String? publishedDate;
  final ImageLinks? imageLinks;

  VolumeInfo({
    required this.title,
    this.subtitle,
    this.description,
    this.authors,
    this.publisher,
    this.publishedDate,
    this.imageLinks,
  });

  factory VolumeInfo.fromJson(Map<String, dynamic> json) {
    return VolumeInfo(
      title: json['title'] ?? 'No Title', // Beri nilai default jika judul null
      subtitle: json['subtitle'],
      description: json['description'],
      authors: json['authors'] as List?,
      publisher: json['publisher'],
      publishedDate: json['publishedDate'],
      imageLinks: json['imageLinks'] != null 
          ? ImageLinks.fromJson(json['imageLinks']) 
          : null,
    );
  }
}

class ImageLinks {
  final String? smallThumbnail;
  final String? thumbnail;

  ImageLinks({this.smallThumbnail, this.thumbnail});

  factory ImageLinks.fromJson(Map<String, dynamic>? json) {
    if (json == null) return ImageLinks(smallThumbnail: '', thumbnail: '');
    return ImageLinks(
      smallThumbnail: json['smallThumbnail'],
      thumbnail: json['thumbnail'],
    );
  }
}

class AccessInfo {
  final String? webReaderLink; // Gunakan final dan ?

  AccessInfo({this.webReaderLink});

  factory AccessInfo.fromJson(Map<String, dynamic> json) {
    return AccessInfo(webReaderLink: json['webReaderLink']);
  }
}

class SaleInfo {
  final String? saleability;
  final String? buyLink;

  SaleInfo({this.saleability, this.buyLink});

  factory SaleInfo.fromJson(Map<String, dynamic> json) {
    return SaleInfo(
      saleability: json['saleability'], 
      buyLink: json['buyLink']
    );
  }
}