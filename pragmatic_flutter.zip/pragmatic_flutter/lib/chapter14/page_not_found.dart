import 'package:flutter/material.dart';

class PageNotFound extends StatelessWidget {
  // 1. Tambahkan constructor dengan super.key
  const PageNotFound({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // 2. Tambahkan const agar performa lebih efisien
        title: const Text("Page Not Found"),
      ),
      body: const Center(
        child: Text("Page is not available."),
      ),
    );
  }
}