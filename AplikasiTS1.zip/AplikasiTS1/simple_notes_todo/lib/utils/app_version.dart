class AppVersion {
  static const String currentVersion = "1.0.0";

  static const String updateDescription =
      "Penambahan fitur login, catatan pribadi, deadline, dan prioritas.";
}
