import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import 'note_form_page.dart';
import '../utils/app_version.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> notes = [];

  Future<void> _loadNotes() async {
    final data = await DatabaseHelper.instance.getNotes();
    setState(() {
      notes = data;
    });
  }

  // POPUP UPDATE VERSI
  void _showUpdateDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Update Aplikasi'),
        content: Text(
          "Versi ${AppVersion.currentVersion}\n\n"
          "${AppVersion.updateDescription}",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _loadNotes();

    Future.delayed(const Duration(milliseconds: 500), () {
      _showUpdateDialog();
    });
  }

  Color _priorityColor(String? priority) {
    switch (priority) {
      case 'Tinggi':
        return Colors.redAccent;
      case 'Sedang':
        return Colors.orangeAccent;
      case 'Rendah':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        title: const Text('Catatan Pribadi'),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NoteFormPage()),
          );
          if (result == true) _loadNotes();
        },
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: notes.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.note_alt_outlined,
                      size: 64, color: Colors.grey),
                  SizedBox(height: 12),
                  Text(
                    'Belum ada catatan',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: notes.length,
              itemBuilder: (context, index) {
                final note = notes[index];

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => NoteFormPage(note: note),
                        ),
                      );
                      if (result == true) _loadNotes();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Title + Delete
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  note['title'],
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline,
                                    color: Colors.red),
                                onPressed: () async {
                                  await DatabaseHelper.instance
                                      .deleteNote(note['id']);
                                  _loadNotes();
                                },
                              ),
                            ],
                          ),

                          const SizedBox(height: 8),
                          Text(
                            note['content'],
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),

                          const SizedBox(height: 12),

                          Row(
                            children: [
                              // Deadline
                              Chip(
                                label: Text(
                                  note['deadline'] != null
                                      ? "Deadline: ${note['deadline'].toString().substring(0, 10)}"
                                      : "Tanpa deadline",
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ),
                              const SizedBox(width: 8),

                              // Priority
                              if (note['priority'] != null)
                                Chip(
                                  backgroundColor:
                                      _priorityColor(note['priority']),
                                  label: Text(
                                    note['priority'],
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8),
        child: Text(
          "Versi Aplikasi ${AppVersion.currentVersion}",
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ),
    );
  }
}
